#!/usr/bin/env python3
"""
DeepSeek Embedding 功能测试脚本
用于验证 DeepSeek embedding 是否正常工作
"""
import os
import sys
from services.embedding_service import EmbeddingService, EmbeddingConfig

def test_deepseek_embedding():
    """测试 DeepSeek embedding 功能"""
    
    # 检查 API key
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        print("❌ 错误: 未设置 DEEPSEEK_API_KEY 环境变量")
        print("请在 ~/.zshrc 中添加: export DEEPSEEK_API_KEY='your-key'")
        return False
    
    print(f"✅ 已找到 DEEPSEEK_API_KEY: {api_key[:20]}...")
    
    # 创建测试数据
    test_chunks = [
        {
            "content": "人工智能是计算机科学的一个分支。",
            "metadata": {
                "chunk_id": 1,
                "page_number": 1,
                "page_range": "1",
                "word_count": 10
            }
        },
        {
            "content": "深度学习是机器学习的一个子领域。",
            "metadata": {
                "chunk_id": 2,
                "page_number": 1,
                "page_range": "1",
                "word_count": 12
            }
        }
    ]
    
    input_data = {
        "chunks": test_chunks,
        "metadata": {
            "filename": "test.pdf",
            "total_chunks": 2,
            "total_pages": 1,
            "loading_method": "test",
            "chunking_method": "test"
        }
    }
    
    # 创建配置
    config = EmbeddingConfig(provider="deepseek", model_name="deepseek-chat")
    
    # 创建 embedding
    print("\n开始创建 DeepSeek embeddings...")
    embedding_service = EmbeddingService()
    
    try:
        embeddings, _ = embedding_service.create_embeddings(input_data, config)
        print(f"✅ 成功创建 {len(embeddings)} 个 embeddings")
        
        # 打印第一个 embedding 的信息
        first_emb = embeddings[0]
        print(f"\n第一个 embedding 信息:")
        print(f"  - 向量维度: {len(first_emb['embedding'])}")
        print(f"  - 内容: {first_emb['metadata']['content']}")
        print(f"  - 提供商: {first_emb['metadata']['embedding_provider']}")
        print(f"  - 模型: {first_emb['metadata']['embedding_model']}")
        print(f"  - 向量前5个值: {first_emb['embedding'][:5]}")
        
        return True
        
    except Exception as e:
        print(f"❌ 创建 embeddings 失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("DeepSeek Embedding 功能测试")
    print("=" * 60)
    
    success = test_deepseek_embedding()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ 测试通过！DeepSeek embedding 功能正常")
    else:
        print("❌ 测试失败！请检查配置和错误信息")
    print("=" * 60)
    
    sys.exit(0 if success else 1)
