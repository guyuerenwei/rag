#!/usr/bin/env python3
"""
测试 Chroma 向量数据库索引功能
"""
import os
import sys
import json

# 添加backend目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from services.vector_store_service import VectorStoreService, VectorDBConfig

def test_chroma_indexing():
    """测试 Chroma 向量数据库索引"""
    print("=" * 60)
    print("测试 Chroma 向量数据库索引功能")
    print("=" * 60)
    
    # 选择一个小文件进行测试
    embedding_file = "02-embedded-docs/074_huggingface_20250103113115.json"
    
    if not os.path.exists(embedding_file):
        print(f"❌ 错误: 文件不存在 {embedding_file}")
        return False
    
    try:
        print(f"\n1. 读取 embedding 文件: {embedding_file}")
        with open(embedding_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            print(f"   ✅ 文件包含 {len(data.get('embeddings', []))} 个 embeddings")
            print(f"   - 文档名: {data.get('filename', 'N/A')}")
            print(f"   - Provider: {data.get('embedding_provider', 'N/A')}")
            print(f"   - Model: {data.get('embedding_model', 'N/A')}")
            print(f"   - 向量维度: {data.get('vector_dimension', 'N/A')}")
        
        print("\n2. 创建 Chroma 配置")
        config = VectorDBConfig(provider="chroma", index_mode="hnsw")
        print(f"   ✅ 配置创建成功")
        print(f"   - Provider: {config.provider}")
        print(f"   - Index Mode: {config.index_mode}")
        print(f"   - Persist Directory: {config.chroma_persist_directory}")
        
        print("\n3. 开始索引到 Chroma 数据库...")
        vector_store_service = VectorStoreService()
        result = vector_store_service.index_embeddings(embedding_file, config)
        
        print("\n4. 索引完成！")
        print(f"   ✅ 数据库: {result.get('database')}")
        print(f"   ✅ 索引模式: {result.get('index_mode')}")
        print(f"   ✅ 总向量数: {result.get('total_vectors')}")
        print(f"   ✅ 索引大小: {result.get('index_size')}")
        print(f"   ✅ 处理时间: {result.get('processing_time'):.2f} 秒")
        print(f"   ✅ Collection 名称: {result.get('collection_name')}")
        
        print("\n5. 列出 Chroma 中的所有 collections")
        collections = vector_store_service.list_collections("chroma")
        print(f"   ✅ 找到 {len(collections)} 个 collections:")
        for col in collections:
            print(f"      - {col}")
        
        print("\n" + "=" * 60)
        print("✅ 测试成功完成！")
        print("=" * 60)
        return True
        
    except Exception as e:
        print(f"\n❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_chroma_indexing()
    sys.exit(0 if success else 1)
