# Chroma 向量数据库集成总结

## 概述
成功将 Chroma 向量数据库集成到 RAG 项目中，现在支持 Milvus 和 Chroma 两种向量数据库。

## 更改的文件

### 1. `/backend/utils/config.py`
**更改内容：**
- 添加 `VectorDBProvider.CHROMA = "chroma"` 到枚举类
- 添加 `CHROMA_CONFIG` 配置字典，包含：
  - `persist_directory`: Chroma 数据库持久化目录
  - `index_types`: 支持的索引类型（hnsw, standard）

### 2. `/backend/services/vector_store_service.py`
**更改内容：**
- 导入 `CHROMA_CONFIG`
- `VectorDBConfig.__init__`: 添加 `chroma_persist_directory` 属性
- `index_embeddings`: 添加 Chroma 分支
- **新增方法** `_index_to_chroma`: 实现 Chroma 数据索引
  - 生成符合 Chroma 命名规范的 collection 名称
  - 创建 PersistentClient 连接
  - 批量插入向量数据和元数据
- `list_collections`: 添加 Chroma 支持
- `delete_collection`: 添加 Chroma 支持
- `get_collection_info`: 添加 Chroma 支持

### 3. `/backend/services/search_service.py`
**更改内容：**
- 导入 `CHROMA_CONFIG`
- `__init__`: 添加 `chroma_persist_directory` 属性
- `get_providers`: 添加 Chroma 到返回列表
- `list_collections`: 添加 Chroma 分支，支持列出 Chroma collections

### 4. `/frontend/src/pages/Indexing.jsx`
**状态：** 前端已经有 Chroma 配置，无需修改
- `dbConfigs` 已包含 chroma 配置
- 支持 hnsw 和 standard 两种索引模式

## 技术特性

### Collection 命名规则
Chroma 要求 collection 名称：
1. 包含 3-63 个字符
2. 以字母数字开头和结尾
3. 只包含字母数字、下划线或连字符
4. 不包含连续的句点
5. 不是有效的 IPv4 地址

**实现：**
- 中文文件名转换为拼音
- 数字开头的文件名添加 "doc_" 前缀
- 格式：`{base_name}_{provider}_{timestamp}`

### 数据结构
存储的元数据包括：
- document_name: 文档名称
- chunk_id: 块ID
- total_chunks: 总块数
- word_count: 字数
- page_number: 页码
- page_range: 页码范围
- embedding_provider: 嵌入提供商
- embedding_model: 嵌入模型
- embedding_timestamp: 时间戳

### 相似度度量
使用余弦相似度（cosine）进行向量搜索

## 测试结果

### 测试脚本: `test_chroma_indexing.py`
**测试内容：**
1. 读取 embedding 文件
2. 创建 Chroma 配置
3. 索引数据到 Chroma
4. 列出所有 collections
5. 验证数据完整性

**测试结果：**
```
✅ 成功创建 9 个 embeddings
✅ 索引完成时间: 0.38 秒
✅ Collection: doc_074_huggingface_20251223220246
✅ 数据库目录: 03-vector-store/chroma_db
```

## API 端点

### 获取支持的数据库提供商
```bash
curl http://localhost:8001/providers
```
返回：
```json
{
  "providers": [
    {"id": "milvus", "name": "Milvus"},
    {"id": "chroma", "name": "Chroma"}
  ]
}
```

### 列出 Chroma Collections
```bash
curl "http://localhost:8001/collections?provider=chroma"
```
返回：
```json
{
  "collections": [
    {
      "id": "doc_074_huggingface_20251223220246",
      "name": "doc_074_huggingface_20251223220246",
      "count": 9
    }
  ]
}
```

### 索引数据到 Chroma
```bash
curl -X POST http://localhost:8001/index \
  -H "Content-Type: application/json" \
  -d '{
    "fileId": "074_huggingface_20250103113115.json",
    "vectorDb": "chroma",
    "indexMode": "hnsw"
  }'
```

### 删除 Chroma Collection
```bash
curl -X DELETE "http://localhost:8001/collections/chroma/{collection_name}"
```

## 使用方法

### 通过前端 UI
1. 访问 http://localhost:5174
2. 进入 "Indexing with Vector DB" 页面
3. 选择一个 embedding 文件
4. 在 "Vector Database" 下拉框选择 "Chroma"
5. 选择索引模式（HNSW 或 STANDARD）
6. 点击 "Index Data" 按钮
7. 查看索引结果

### 通过 Python API
```python
from services.vector_store_service import VectorStoreService, VectorDBConfig

# 创建配置
config = VectorDBConfig(provider="chroma", index_mode="hnsw")

# 创建服务
service = VectorStoreService()

# 索引数据
result = service.index_embeddings("path/to/embedding.json", config)

# 列出 collections
collections = service.list_collections("chroma")

# 获取 collection 信息
info = service.get_collection_info("chroma", "collection_name")

# 删除 collection
success = service.delete_collection("chroma", "collection_name")
```

## 性能对比

### 测试数据
- 文件：074.pdf
- Embeddings: 9 个
- 向量维度: 384
- Provider: HuggingFace (all-MiniLM-L6-v2)

### 索引性能
- **Chroma**: 0.38 秒
- **存储位置**: 03-vector-store/chroma_db

## 依赖包
已安装的 Chroma 相关包：
- chromadb==0.5.3
- chroma-hnswlib==0.7.3
- langchain-chroma==0.1.4

## 文件结构
```
backend/
├── 03-vector-store/
│   ├── chroma_db/          # Chroma 数据库目录
│   └── langchain_milvus.db # Milvus 数据库文件
├── services/
│   ├── vector_store_service.py
│   └── search_service.py
├── utils/
│   └── config.py
└── test_chroma_indexing.py
```

## 注意事项

1. **命名规范**: Chroma collection 名称必须符合严格的命名规范
2. **持久化**: Chroma 使用 PersistentClient，数据会自动持久化到磁盘
3. **元数据**: Chroma 的元数据必须是字符串类型，数字需要转换
4. **向量维度**: 必须与 embedding 模型的输出维度一致
5. **相似度**: 默认使用余弦相似度（cosine）

## 后续可能的优化

1. **搜索功能**: 实现 Chroma 的向量搜索（类似 Milvus 的搜索功能）
2. **混合搜索**: 支持向量搜索 + 关键词搜索
3. **批量操作**: 优化大规模数据的批量插入
4. **性能监控**: 添加索引和搜索性能监控
5. **错误处理**: 增强错误处理和日志记录

## 测试覆盖

✅ Collection 创建
✅ 数据索引
✅ Collection 列表
✅ Collection 信息查询
✅ Collection 删除
⏳ 向量搜索（待实现）

## 总结

Chroma 向量数据库已成功集成到 RAG 项目中，提供了与 Milvus 并行的向量存储能力。用户现在可以根据需求选择合适的向量数据库进行数据索引和管理。
