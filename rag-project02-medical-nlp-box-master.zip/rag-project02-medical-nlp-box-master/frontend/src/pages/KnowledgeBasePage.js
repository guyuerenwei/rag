import React, { useState, useEffect } from 'react';
import { Upload, FileText, Folder, Type, Play, RefreshCw, Database, Search, Eye, Trash2, Settings, CheckCircle, AlertCircle } from 'lucide-react';
import { EmbeddingOptions } from '../components/shared/ModelOptions';

const KnowledgeBasePage = () => {
  const [sourceType, setSourceType] = useState('file');
  const [filePath, setFilePath] = useState('');
  const [directoryPath, setDirectoryPath] = useState('');
  const [textContent, setTextContent] = useState('');
  const [splitMethod, setSplitMethod] = useState('recursive');
  const [splitMethods, setSplitMethods] = useState({});
  const [splitParams, setSplitParams] = useState({
    chunk_size: 1000,
    chunk_overlap: 200,
    language: 'chinese'
  });
  const [embeddingOptions, setEmbeddingOptions] = useState({
    provider: 'huggingface',
    model: 'BAAI/bge-m3',
    dbName: 'finance_terms_kb',
    collectionName: 'finance_terms_kb'
  });
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [buildStatus, setBuildStatus] = useState('');
  const [buildResult, setBuildResult] = useState(null);
  const [error, setError] = useState('');
  const [kbStats, setKbStats] = useState(null);
  const [previewChunks, setPreviewChunks] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState('build');
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    fetchSplitMethods();
    fetchKbStats();
  }, []);

  const fetchSplitMethods = async () => {
    try {
      const response = await fetch('http://127.0.0.1:8000/api/split/methods');
      const data = await response.json();
      setSplitMethods(data.methods);
    } catch (error) {
      console.error('Error fetching split methods:', error);
    }
  };

  const fetchKbStats = async () => {
    try {
      const response = await fetch(`http://127.0.0.1:8000/api/kb/stats?dbName=${embeddingOptions.dbName}&collectionName=${embeddingOptions.collectionName}`);
      const data = await response.json();
      console.log('KB Stats response:', data);
      setKbStats(data.stats);
    } catch (error) {
      console.error('Error fetching KB stats:', error);
    }
  };

  const fetchPreviewChunks = async () => {
    try {
      const response = await fetch(`http://127.0.0.1:8000/api/kb/preview?limit=5&dbName=${embeddingOptions.dbName}&collectionName=${embeddingOptions.collectionName}`);
      const data = await response.json();
      console.log('Preview chunks response:', data);
      setPreviewChunks(data.chunks || []);
    } catch (error) {
      console.error('Error fetching preview chunks:', error);
    }
  };

  const handleBuild = async () => {
    setIsBuilding(true);
    setError('');
    setBuildResult(null);
    setBuildProgress(0);
    setBuildStatus('准备开始构建...');

    try {
      const payload = {
        sourceType,
        filePath: sourceType === 'file' ? filePath : undefined,
        directoryPath: sourceType === 'directory' ? directoryPath : undefined,
        text: sourceType === 'text' ? textContent : undefined,
        splitMethod,
        splitParams,
        embeddingOptions
      };

      const response = await fetch('http://127.0.0.1:8000/api/kb/build', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.progress_updates && data.progress_updates.length > 0) {
        const updates = data.progress_updates;
        for (const update of updates) {
          setBuildProgress(update.progress);
          setBuildStatus(update.message);
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }

      setBuildResult(data.result);
      setBuildStatus('构建完成！');
      fetchKbStats();
      fetchPreviewChunks();

    } catch (error) {
      console.error('Error:', error);
      setError(`构建失败: ${error.message}`);
      setBuildStatus('构建失败');
    }

    setIsBuilding(false);
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    try {
      const response = await fetch('http://127.0.0.1:8000/api/kb/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: searchQuery,
          limit: 5,
          embeddingOptions
        }),
      });
      const data = await response.json();
      setSearchResults(data.results);
    } catch (error) {
      console.error('Error:', error);
      setError(`搜索失败: ${error.message}`);
    }
    setIsSearching(false);
  };

  const handleClearKb = async () => {
    if (!window.confirm('确定要清空知识库吗？此操作不可恢复。')) return;

    try {
      const response = await fetch(`http://127.0.0.1:8000/api/kb/clear?dbName=${embeddingOptions.dbName}&collectionName=${embeddingOptions.collectionName}`, {
        method: 'DELETE',
      });
      const data = await response.json();
      setKbStats(null);
      setPreviewChunks([]);
      setSearchResults([]);
      alert('知识库已清空');
    } catch (error) {
      console.error('Error:', error);
      setError(`清空失败: ${error.message}`);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('http://127.0.0.1:8000/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      setFilePath(data.filePath);
    } catch (error) {
      console.error('Error uploading file:', error);
      setError(`文件上传失败: ${error.message}`);
    }
    setIsUploading(false);
  };

  const renderSourceInput = () => {
    switch (sourceType) {
      case 'file':
        return (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">文件路径</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={filePath}
                onChange={(e) => setFilePath(e.target.value)}
                className="flex-1 border border-gray-300 rounded-md px-3 py-2"
                placeholder="请输入文件路径，如: /path/to/file.pdf"
              />
              <input
                type="file"
                id="file-upload"
                className="hidden"
                onChange={handleFileUpload}
              />
              <button
                onClick={() => document.getElementById('file-upload').click()}
                disabled={isUploading}
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 flex items-center gap-2 disabled:bg-gray-400"
              >
                <Upload size={16} />
                {isUploading ? '上传中...' : '选择文件'}
              </button>
            </div>
          </div>
        );
      case 'directory':
        return (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">目录路径</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={directoryPath}
                onChange={(e) => setDirectoryPath(e.target.value)}
                className="flex-1 border border-gray-300 rounded-md px-3 py-2"
                placeholder="请输入目录路径，如: /path/to/directory"
              />
              <button
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.webkitdirectory = true;
                  input.onchange = (e) => setDirectoryPath(e.target.files[0]?.webkitRelativePath?.split('/')[0] || '');
                  input.click();
                }}
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 flex items-center gap-2"
              >
                <Folder size={16} />
                选择目录
              </button>
            </div>
          </div>
        );
      case 'text':
        return (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">文本内容</label>
            <textarea
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              rows={6}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
              placeholder="请输入或粘贴文本内容..."
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">金融术语知识库构建 📚</h1>

      <div className="mb-4">
        <div className="flex gap-2 border-b">
          <button
            onClick={() => setActiveTab('build')}
            className={`px-4 py-2 font-medium ${activeTab === 'build' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
          >
            构建知识库
          </button>
          <button
            onClick={() => setActiveTab('search')}
            className={`px-4 py-2 font-medium ${activeTab === 'search' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
          >
            搜索知识库
          </button>
          <button
            onClick={() => setActiveTab('manage')}
            className={`px-4 py-2 font-medium ${activeTab === 'manage' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
          >
            管理知识库
          </button>
        </div>
      </div>

      {activeTab === 'build' && (
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 space-y-6">
            <div className="bg-white shadow-md rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Upload size={20} />
                数据源选择
              </h2>

              <div className="flex gap-4 mb-4">
                <button
                  onClick={() => setSourceType('file')}
                  className={`flex-1 p-4 rounded-lg border-2 flex flex-col items-center gap-2 ${sourceType === 'file' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}
                >
                  <FileText size={24} />
                  <span className="font-medium">文件导入</span>
                  <span className="text-xs text-gray-500">CSV、PDF、MD、TXT</span>
                </button>
                <button
                  onClick={() => setSourceType('directory')}
                  className={`flex-1 p-4 rounded-lg border-2 flex flex-col items-center gap-2 ${sourceType === 'directory' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}
                >
                  <Folder size={24} />
                  <span className="font-medium">目录导入</span>
                  <span className="text-xs text-gray-500">批量导入多个文件</span>
                </button>
                <button
                  onClick={() => setSourceType('text')}
                  className={`flex-1 p-4 rounded-lg border-2 flex flex-col items-center gap-2 ${sourceType === 'text' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}
                >
                  <Type size={24} />
                  <span className="font-medium">文本输入</span>
                  <span className="text-xs text-gray-500">直接输入文本</span>
                </button>
              </div>

              {renderSourceInput()}
            </div>

            <div className="bg-white shadow-md rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Settings size={20} />
                文本切分设置
              </h2>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">切分方法</label>
                <select
                  value={splitMethod}
                  onChange={(e) => setSplitMethod(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2"
                >
                  {Object.entries(splitMethods).map(([key, info]) => (
                    <option key={key} value={key}>
                      {info.name} - {info.use_case}
                    </option>
                  ))}
                </select>
                {splitMethods[splitMethod] && (
                  <p className="text-sm text-gray-500 mt-2">{splitMethods[splitMethod].description}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">块大小</label>
                  <input
                    type="number"
                    value={splitParams.chunk_size}
                    onChange={(e) => setSplitParams({...splitParams, chunk_size: parseInt(e.target.value)})}
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">块重叠</label>
                  <input
                    type="number"
                    value={splitParams.chunk_overlap}
                    onChange={(e) => setSplitParams({...splitParams, chunk_overlap: parseInt(e.target.value)})}
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">语言</label>
                <select
                  value={splitParams.language}
                  onChange={(e) => setSplitParams({...splitParams, language: e.target.value})}
                  className="w-full border border-gray-300 rounded-md px-3 py-2"
                >
                  <option value="chinese">中文</option>
                  <option value="english">英文</option>
                </select>
              </div>
            </div>

            <div className="bg-white shadow-md rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Database size={20} />
                向量数据库配置
              </h2>

              <EmbeddingOptions options={embeddingOptions} onChange={(e) => {
                const { name, value } = e.target;
                setEmbeddingOptions(prev => ({ ...prev, [name]: value }));
              }} />
            </div>

            <button
              onClick={handleBuild}
              disabled={isBuilding}
              className="w-full bg-blue-500 text-white px-4 py-3 rounded-md hover:bg-blue-600 disabled:bg-gray-400 flex items-center justify-center gap-2"
            >
              {isBuilding ? (
                <>
                  <RefreshCw className="animate-spin" size={20} />
                  构建中...
                </>
              ) : (
                <>
                  <Play size={20} />
                  开始构建知识库
                </>
              )}
            </button>

            {isBuilding && (
              <div className="bg-white shadow-md rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{buildStatus}</span>
                  <span className="text-sm text-gray-500">{buildProgress.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
                  <div
                    className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${buildProgress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500">
                  💡 提示：处理PDF文件需要较长时间，请耐心等待。处理时间取决于文件大小和内容复杂度。
                </p>
              </div>
            )}

            {buildResult && (
              <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4">
                <h3 className="font-bold mb-2">构建完成</h3>
                <pre className="text-sm">{JSON.stringify(buildResult, null, 2)}</pre>
              </div>
            )}

            {error && (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                <p className="font-bold">错误：</p>
                <p>{error}</p>
              </div>
            )}
          </div>

          <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">知识库状态</h2>
            {kbStats ? (
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">总块数:</span>
                  <span className="font-medium">{kbStats.total_count}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">数据库名:</span>
                  <span className="font-medium">{kbStats.collection_name}</span>
                </div>
              </div>
            ) : (
              <p className="text-gray-500">知识库为空，请先构建知识库</p>
            )}

            {previewChunks && previewChunks.length > 0 && (
              <div className="mt-6">
                <h3 className="font-semibold mb-3">内容预览</h3>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {previewChunks.map((chunk, index) => (
                    <div key={index} className="bg-gray-50 p-3 rounded-md">
                      <p className="text-sm text-gray-700 line-clamp-3">{chunk.content}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'search' && (
        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Search size={20} />
            搜索知识库
          </h2>

          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1 border border-gray-300 rounded-md px-3 py-2"
              placeholder="请输入搜索关键词..."
            />
            <button
              onClick={handleSearch}
              disabled={isSearching}
              className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 disabled:bg-gray-400 flex items-center gap-2"
            >
              {isSearching ? <RefreshCw className="animate-spin" size={16} /> : <Search size={16} />}
              搜索
            </button>
          </div>

          {searchResults.length > 0 && (
            <div className="space-y-4">
              {searchResults.map((result, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm text-gray-500">相似度: {(1 - result.distance).toFixed(4)}</span>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">结果 {index + 1}</span>
                  </div>
                  <p className="text-gray-700">{result.content}</p>
                  {result.metadata && Object.keys(result.metadata).length > 0 && (
                    <div className="mt-2 text-xs text-gray-500">
                      {Object.entries(result.metadata).map(([key, value]) => (
                        <span key={key} className="mr-3">
                          {key}: {value}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {searchResults.length === 0 && searchQuery && !isSearching && (
            <p className="text-gray-500 text-center py-8">未找到相关结果</p>
          )}
        </div>
      )}

      {activeTab === 'manage' && (
        <div className="space-y-6">
          <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Database size={20} />
              知识库管理
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <div className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Eye size={20} className="text-blue-500" />
                  <span className="font-medium">查看统计</span>
                </div>
                <p className="text-sm text-gray-600 mb-3">查看知识库的统计信息</p>
                <button
                  onClick={fetchKbStats}
                  className="w-full bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
                >
                  刷新统计
                </button>
              </div>

              <div className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trash2 size={20} className="text-red-500" />
                  <span className="font-medium">清空知识库</span>
                </div>
                <p className="text-sm text-gray-600 mb-3">删除知识库中的所有数据</p>
                <button
                  onClick={handleClearKb}
                  className="w-full bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600"
                >
                  清空知识库
                </button>
              </div>
            </div>

            {kbStats && (
              <div className="mt-6 border rounded-lg p-4">
                <h3 className="font-semibold mb-3">知识库统计</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-600">总块数</p>
                    <p className="text-2xl font-bold text-blue-600">{kbStats.total_count}</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-600">集合名称</p>
                    <p className="text-lg font-semibold text-green-600">{kbStats.collection_name}</p>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-600">数据库路径</p>
                    <p className="text-sm text-purple-600 truncate">{kbStats.db_path}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBasePage;
