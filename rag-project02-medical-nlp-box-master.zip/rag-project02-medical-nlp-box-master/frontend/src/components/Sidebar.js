import React from 'react';
import { Link } from 'react-router-dom';
import { DollarSign, Database } from 'lucide-react';

const Sidebar = ({ width }) => {
  return (
    <div className="bg-white shadow-lg" style={{ width: `${width}px` }}>
      <div className="p-5">
        <img src="/images/medical-icon.png" alt="金融图标" className="w-16 h-16 mx-auto mb-4" />
        <h1 className="text-xl font-bold mb-2">金融术语标准化系统</h1>
        <p className="text-sm text-gray-600 mb-4">专业的金融术语标准化工具</p>
      </div>
      <nav className="mt-5">
        <Link to="/fin-std" className="flex items-center p-3 text-gray-700 hover:bg-gray-100">
          <DollarSign className="mr-3" /> 金融术语标准化
        </Link>
        <Link to="/knowledge-base" className="flex items-center p-3 text-gray-700 hover:bg-gray-100">
          <Database className="mr-3" /> 知识库构建
        </Link>
      </nav>
    </div>
  );
};

export default Sidebar;
