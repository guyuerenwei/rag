from langchain_community.document_loaders import (
    TextLoader,
    CSVLoader,
    PyPDFLoader,
    UnstructuredMarkdownLoader,
    DirectoryLoader,
    JSONLoader
)
from langchain_core.documents import Document
from typing import List, Dict, Optional, Literal
import logging
import os
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FileImportService:
    """
    文件导入服务
    支持多种文件格式的导入：CSV、PDF、Markdown、TXT、JSON等
    """
    
    SUPPORTED_FORMATS = {
        '.txt': 'text',
        '.csv': 'csv',
        '.pdf': 'pdf',
        '.md': 'markdown',
        '.json': 'json'
    }
    
    def __init__(self):
        self.loaded_documents = []
    
    def import_file(self, file_path: str, **kwargs) -> List[Document]:
        """
        导入单个文件
        
        Args:
            file_path: 文件路径
            **kwargs: 加载器特定参数
            
        Returns:
            Document对象列表
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        file_ext = file_path.suffix.lower()
        
        if file_ext not in self.SUPPORTED_FORMATS:
            raise ValueError(f"不支持的文件格式: {file_ext}. 支持的格式: {list(self.SUPPORTED_FORMATS.keys())}")
        
        try:
            loader = self._create_loader(file_path, file_ext, **kwargs)
            documents = loader.load()
            
            for doc in documents:
                doc.metadata['source'] = str(file_path)
                doc.metadata['file_type'] = self.SUPPORTED_FORMATS[file_ext]
            
            logger.info(f"成功导入文件: {file_path}, 文档数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入文件失败: {file_path}, 错误: {str(e)}")
            raise
    
    def import_directory(self, directory_path: str, glob_pattern: str = "**/*", **kwargs) -> List[Document]:
        """
        批量导入目录中的文件
        
        Args:
            directory_path: 目录路径
            glob_pattern: 文件匹配模式
            **kwargs: 加载器参数
            
        Returns:
            Document对象列表
        """
        directory_path = Path(directory_path)
        
        if not directory_path.exists() or not directory_path.is_dir():
            raise NotADirectoryError(f"目录不存在或不是有效目录: {directory_path}")
        
        try:
            loader = DirectoryLoader(
                path=str(directory_path),
                glob=glob_pattern,
                show_progress=True,
                use_multithreading=True,
                max_concurrency=4,
                silent_errors=True,
                loader_kwargs=kwargs
            )
            
            documents = loader.load()
            
            for doc in documents:
                if 'source' not in doc.metadata:
                    doc.metadata['source'] = str(doc.metadata.get('source', ''))
                file_ext = Path(doc.metadata['source']).suffix.lower()
                doc.metadata['file_type'] = self.SUPPORTED_FORMATS.get(file_ext, 'unknown')
            
            logger.info(f"成功导入目录: {directory_path}, 文档数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入目录失败: {directory_path}, 错误: {str(e)}")
            raise
    
    def import_csv(self, file_path: str, source_column: Optional[str] = None, **kwargs) -> List[Document]:
        """
        导入CSV文件
        
        Args:
            file_path: CSV文件路径
            source_column: 作为文档来源的列名
            **kwargs: CSVLoader参数
            
        Returns:
            Document对象列表
        """
        try:
            loader = CSVLoader(
                file_path=file_path,
                source_column=source_column,
                encoding="utf-8",
                **kwargs
            )
            documents = loader.load()
            
            for doc in documents:
                doc.metadata['source'] = file_path
                doc.metadata['file_type'] = 'csv'
            
            logger.info(f"成功导入CSV文件: {file_path}, 记录数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入CSV文件失败: {file_path}, 错误: {str(e)}")
            raise
    
    def import_pdf(self, file_path: str, **kwargs) -> List[Document]:
        """
        导入PDF文件
        
        Args:
            file_path: PDF文件路径
            **kwargs: PyPDFLoader参数
            
        Returns:
            Document对象列表（按页分割）
        """
        try:
            loader = PyPDFLoader(file_path, **kwargs)
            documents = loader.load()
            
            for i, doc in enumerate(documents):
                doc.metadata['source'] = file_path
                doc.metadata['file_type'] = 'pdf'
                doc.metadata['page'] = i + 1
            
            logger.info(f"成功导入PDF文件: {file_path}, 页数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入PDF文件失败: {file_path}, 错误: {str(e)}")
            raise
    
    def import_markdown(self, file_path: str, **kwargs) -> List[Document]:
        """
        导入Markdown文件
        
        Args:
            file_path: Markdown文件路径
            **kwargs: UnstructuredMarkdownLoader参数
            
        Returns:
            Document对象列表
        """
        try:
            loader = UnstructuredMarkdownLoader(file_path, **kwargs)
            documents = loader.load()
            
            for doc in documents:
                doc.metadata['source'] = file_path
                doc.metadata['file_type'] = 'markdown'
            
            logger.info(f"成功导入Markdown文件: {file_path}, 文档数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入Markdown文件失败: {file_path}, 错误: {str(e)}")
            raise
    
    def import_text(self, file_path: str, encoding: str = "utf-8", **kwargs) -> List[Document]:
        """
        导入纯文本文件
        
        Args:
            file_path: 文本文件路径
            encoding: 文件编码
            **kwargs: TextLoader参数
            
        Returns:
            Document对象列表
        """
        try:
            loader = TextLoader(
                file_path=file_path,
                encoding=encoding,
                autodetect_encoding=True,
                **kwargs
            )
            documents = loader.load()
            
            for doc in documents:
                doc.metadata['source'] = file_path
                doc.metadata['file_type'] = 'text'
            
            logger.info(f"成功导入文本文件: {file_path}, 文档数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入文本文件失败: {file_path}, 错误: {str(e)}")
            raise
    
    def import_json(self, file_path: str, jq_schema: Optional[str] = None, **kwargs) -> List[Document]:
        """
        导入JSON文件
        
        Args:
            file_path: JSON文件路径
            jq_schema: JQ查询模式
            **kwargs: JSONLoader参数
            
        Returns:
            Document对象列表
        """
        try:
            loader = JSONLoader(
                file_path=file_path,
                jq_schema=jq_schema,
                text_content=True,
                **kwargs
            )
            documents = loader.load()
            
            for doc in documents:
                doc.metadata['source'] = file_path
                doc.metadata['file_type'] = 'json'
            
            logger.info(f"成功导入JSON文件: {file_path}, 文档数: {len(documents)}")
            return documents
            
        except Exception as e:
            logger.error(f"导入JSON文件失败: {file_path}, 错误: {str(e)}")
            raise
    
    def _create_loader(self, file_path: Path, file_ext: str, **kwargs):
        """
        根据文件扩展名创建对应的加载器
        
        Args:
            file_path: 文件路径
            file_ext: 文件扩展名
            **kwargs: 加载器参数
            
        Returns:
            加载器实例
        """
        format_type = self.SUPPORTED_FORMATS[file_ext]
        
        if format_type == 'text':
            return TextLoader(str(file_path), encoding="utf-8", autodetect_encoding=True, **kwargs)
        elif format_type == 'csv':
            return CSVLoader(str(file_path), encoding="utf-8", **kwargs)
        elif format_type == 'pdf':
            return PyPDFLoader(str(file_path), **kwargs)
        elif format_type == 'markdown':
            return UnstructuredMarkdownLoader(str(file_path), **kwargs)
        elif format_type == 'json':
            return JSONLoader(str(file_path), text_content=True, **kwargs)
        else:
            raise ValueError(f"不支持的文件类型: {format_type}")
    
    def get_supported_formats(self) -> List[str]:
        """
        获取支持的文件格式列表
        
        Returns:
            支持的文件扩展名列表
        """
        return list(self.SUPPORTED_FORMATS.keys())
    
    def create_document_from_text(self, text: str, metadata: Optional[Dict] = None) -> Document:
        """
        从文本内容创建Document对象
        
        Args:
            text: 文本内容
            metadata: 元数据字典
            
        Returns:
            Document对象
        """
        if metadata is None:
            metadata = {}
        
        return Document(page_content=text, metadata=metadata)
    
    def create_documents_from_list(self, text_list: List[str], metadata_list: Optional[List[Dict]] = None) -> List[Document]:
        """
        从文本列表创建Document对象列表
        
        Args:
            text_list: 文本内容列表
            metadata_list: 元数据字典列表
            
        Returns:
            Document对象列表
        """
        documents = []
        
        if metadata_list is None:
            metadata_list = [{}] * len(text_list)
        
        for text, metadata in zip(text_list, metadata_list):
            documents.append(self.create_document_from_text(text, metadata))
        
        return documents
