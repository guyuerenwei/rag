from langchain_text_splitters import (
    RecursiveCharacterTextSplitter,
    CharacterTextSplitter,
    TokenTextSplitter
)
from langchain_core.documents import Document
from typing import List, Dict, Optional, Literal
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TextSplitterService:
    """
    文本切分服务
    支持多种切分策略：字符切分、递归字符切分、Token切分等
    """
    
    SPLITTER_TYPES = {
        'character': 'CharacterTextSplitter',
        'recursive': 'RecursiveCharacterTextSplitter',
        'token': 'TokenTextSplitter'
    }
    
    def __init__(self):
        self.chunks = []
    
    def split_by_character(
        self,
        documents: List[Document],
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        separator: str = "\n\n"
    ) -> List[Document]:
        """
        基于字符的文本切分
        
        Args:
            documents: 文档列表
            chunk_size: 每个块的字符数
            chunk_overlap: 块之间的重叠字符数
            separator: 分隔符
            
        Returns:
            切分后的文档块列表
        """
        try:
            text_splitter = CharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                separator=separator,
                length_function=len
            )
            
            chunks = text_splitter.split_documents(documents)
            
            for i, chunk in enumerate(chunks):
                chunk.metadata['splitter_type'] = 'character'
                chunk.metadata['chunk_index'] = i
                chunk.metadata['chunk_size'] = chunk_size
                chunk.metadata['chunk_overlap'] = chunk_overlap
            
            logger.info(f"字符切分完成: 原始文档数={len(documents)}, 生成块数={len(chunks)}")
            return chunks
            
        except Exception as e:
            logger.error(f"字符切分失败: {str(e)}")
            raise
    
    def split_by_recursive(
        self,
        documents: List[Document],
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        separators: Optional[List[str]] = None,
        language: Literal["chinese", "english"] = "chinese"
    ) -> List[Document]:
        """
        递归字符文本切分（推荐）
        优先在自然边界（段落、句子）进行切分
        
        Args:
            documents: 文档列表
            chunk_size: 每个块的字符数
            chunk_overlap: 块之间的重叠字符数
            separators: 自定义分隔符列表
            language: 语言类型
            
        Returns:
            切分后的文档块列表
        """
        try:
            if separators is None:
                if language == "chinese":
                    separators = ["\n\n", "。", "！", "？", "；", "，", " ", ""]
                else:
                    separators = ["\n\n", "\n", ". ", "! ", "? ", "; ", ", ", " ", ""]
            
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                separators=separators,
                length_function=len
            )
            
            chunks = text_splitter.split_documents(documents)
            
            for i, chunk in enumerate(chunks):
                chunk.metadata['splitter_type'] = 'recursive'
                chunk.metadata['chunk_index'] = i
                chunk.metadata['chunk_size'] = chunk_size
                chunk_overlap=chunk_overlap
                chunk.metadata['language'] = language
            
            logger.info(f"递归切分完成: 原始文档数={len(documents)}, 生成块数={len(chunks)}")
            return chunks
            
        except Exception as e:
            logger.error(f"递归切分失败: {str(e)}")
            raise
    
    def split_by_token(
        self,
        documents: List[Document],
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        encoding_name: str = "cl100k_base"
    ) -> List[Document]:
        """
        基于Token的文本切分
        适用于需要精确控制token数量的场景
        
        Args:
            documents: 文档列表
            chunk_size: 每个块的token数
            chunk_overlap: 块之间的重叠token数
            encoding_name: Token编码名称（如cl100k_base用于GPT-4）
            
        Returns:
            切分后的文档块列表
        """
        try:
            text_splitter = TokenTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                encoding_name=encoding_name
            )
            
            chunks = text_splitter.split_documents(documents)
            
            for i, chunk in enumerate(chunks):
                chunk.metadata['splitter_type'] = 'token'
                chunk.metadata['chunk_index'] = i
                chunk.metadata['chunk_size'] = chunk_size
                chunk.metadata['chunk_overlap'] = chunk_overlap
                chunk.metadata['encoding_name'] = encoding_name
            
            logger.info(f"Token切分完成: 原始文档数={len(documents)}, 生成块数={len(chunks)}")
            return chunks
            
        except Exception as e:
            logger.error(f"Token切分失败: {str(e)}")
            raise
    
    def split_by_paragraph(
        self,
        documents: List[Document],
        max_paragraphs_per_chunk: int = 3,
        paragraph_separator: str = "\n\n"
    ) -> List[Document]:
        """
        按段落切分文本
        
        Args:
            documents: 文档列表
            max_paragraphs_per_chunk: 每个块包含的最大段落数
            paragraph_separator: 段落分隔符
            
        Returns:
            切分后的文档块列表
        """
        try:
            chunks = []
            chunk_index = 0
            
            for doc in documents:
                paragraphs = doc.page_content.split(paragraph_separator)
                paragraphs = [p.strip() for p in paragraphs if p.strip()]
                
                for i in range(0, len(paragraphs), max_paragraphs_per_chunk):
                    chunk_text = paragraph_separator.join(
                        paragraphs[i:i + max_paragraphs_per_chunk]
                    )
                    
                    if chunk_text:
                        chunk = Document(
                            page_content=chunk_text,
                            metadata={
                                **doc.metadata,
                                'splitter_type': 'paragraph',
                                'chunk_index': chunk_index,
                                'max_paragraphs_per_chunk': max_paragraphs_per_chunk
                            }
                        )
                        chunks.append(chunk)
                        chunk_index += 1
            
            logger.info(f"段落切分完成: 原始文档数={len(documents)}, 生成块数={len(chunks)}")
            return chunks
            
        except Exception as e:
            logger.error(f"段落切分失败: {str(e)}")
            raise
    
    def split_by_sentence(
        self,
        documents: List[Document],
        max_sentences_per_chunk: int = 5,
        language: Literal["chinese", "english"] = "chinese"
    ) -> List[Document]:
        """
        按句子切分文本
        
        Args:
            documents: 文档列表
            max_sentences_per_chunk: 每个块包含的最大句子数
            language: 语言类型
            
        Returns:
            切分后的文档块列表
        """
        try:
            chunks = []
            chunk_index = 0
            
            if language == "chinese":
                sentence_endings = ["。", "！", "？", "；"]
            else:
                sentence_endings = [". ", "! ", "? ", "; "]
            
            for doc in documents:
                text = doc.page_content
                sentences = []
                current_sentence = ""
                
                for char in text:
                    current_sentence += char
                    if any(ending in current_sentence for ending in sentence_endings):
                        sentences.append(current_sentence.strip())
                        current_sentence = ""
                
                if current_sentence.strip():
                    sentences.append(current_sentence.strip())
                
                sentences = [s for s in sentences if s]
                
                for i in range(0, len(sentences), max_sentences_per_chunk):
                    chunk_text = " ".join(sentences[i:i + max_sentences_per_chunk])
                    
                    if chunk_text:
                        chunk = Document(
                            page_content=chunk_text,
                            metadata={
                                **doc.metadata,
                                'splitter_type': 'sentence',
                                'chunk_index': chunk_index,
                                'max_sentences_per_chunk': max_sentences_per_chunk,
                                'language': language
                            }
                        )
                        chunks.append(chunk)
                        chunk_index += 1
            
            logger.info(f"句子切分完成: 原始文档数={len(documents)}, 生成块数={len(chunks)}")
            return chunks
            
        except Exception as e:
            logger.error(f"句子切分失败: {str(e)}")
            raise
    
    def split_by_fixed_length(
        self,
        documents: List[Document],
        chunk_size: int = 500,
        chunk_overlap: int = 50
    ) -> List[Document]:
        """
        按固定长度切分文本（不考虑语义边界）
        
        Args:
            documents: 文档列表
            chunk_size: 每个块的字符数
            chunk_overlap: 块之间的重叠字符数
            
        Returns:
            切分后的文档块列表
        """
        try:
            chunks = []
            chunk_index = 0
            
            for doc in documents:
                text = doc.page_content
                step = chunk_size - chunk_overlap
                
                for i in range(0, len(text), step):
                    chunk_text = text[i:i + chunk_size]
                    
                    if chunk_text:
                        chunk = Document(
                            page_content=chunk_text,
                            metadata={
                                **doc.metadata,
                                'splitter_type': 'fixed_length',
                                'chunk_index': chunk_index,
                                'chunk_size': chunk_size,
                                'chunk_overlap': chunk_overlap
                            }
                        )
                        chunks.append(chunk)
                        chunk_index += 1
            
            logger.info(f"固定长度切分完成: 原始文档数={len(documents)}, 生成块数={len(chunks)}")
            return chunks
            
        except Exception as e:
            logger.error(f"固定长度切分失败: {str(e)}")
            raise
    
    def split_documents(
        self,
        documents: List[Document],
        method: Literal["character", "recursive", "token", "paragraph", "sentence", "fixed_length"] = "recursive",
        **kwargs
    ) -> List[Document]:
        """
        统一的文档切分接口
        
        Args:
            documents: 文档列表
            method: 切分方法
            **kwargs: 切分参数
            
        Returns:
            切分后的文档块列表
        """
        if method == "character":
            return self.split_by_character(documents, **kwargs)
        elif method == "recursive":
            return self.split_by_recursive(documents, **kwargs)
        elif method == "token":
            return self.split_by_token(documents, **kwargs)
        elif method == "paragraph":
            return self.split_by_paragraph(documents, **kwargs)
        elif method == "sentence":
            return self.split_by_sentence(documents, **kwargs)
        elif method == "fixed_length":
            return self.split_by_fixed_length(documents, **kwargs)
        else:
            raise ValueError(f"不支持的切分方法: {method}")
    
    def get_splitter_info(self, method: str) -> Dict:
        """
        获取切分方法的信息
        
        Args:
            method: 切分方法名称
            
        Returns:
            切分方法信息字典
        """
        info = {
            "character": {
                "name": "字符切分",
                "description": "基于固定字符数切分，不考虑语义边界",
                "default_params": {
                    "chunk_size": 1000,
                    "chunk_overlap": 200,
                    "separator": "\n\n"
                },
                "use_case": "对语义完整性要求不高的场景"
            },
            "recursive": {
                "name": "递归字符切分",
                "description": "优先在自然边界（段落、句子）切分，保持语义完整性",
                "default_params": {
                    "chunk_size": 1000,
                    "chunk_overlap": 200,
                    "language": "chinese"
                },
                "use_case": "大多数通用场景，推荐使用"
            },
            "token": {
                "name": "Token切分",
                "description": "基于Token数量切分，精确控制token数",
                "default_params": {
                    "chunk_size": 500,
                    "chunk_overlap": 50,
                    "encoding_name": "cl100k_base"
                },
                "use_case": "需要精确控制token数量的场景"
            },
            "paragraph": {
                "name": "段落切分",
                "description": "按段落切分，每块包含指定数量的段落",
                "default_params": {
                    "max_paragraphs_per_chunk": 3,
                    "paragraph_separator": "\n\n"
                },
                "use_case": "需要保持段落完整性的场景"
            },
            "sentence": {
                "name": "句子切分",
                "description": "按句子切分，每块包含指定数量的句子",
                "default_params": {
                    "max_sentences_per_chunk": 5,
                    "language": "chinese"
                },
                "use_case": "需要严格保持句子完整性的场景"
            },
            "fixed_length": {
                "name": "固定长度切分",
                "description": "按固定长度切分，不考虑语义边界",
                "default_params": {
                    "chunk_size": 500,
                    "chunk_overlap": 50
                },
                "use_case": "快速原型开发，对语义要求不高"
            }
        }
        
        return info.get(method, {})
    
    def get_supported_methods(self) -> List[str]:
        """
        获取支持的切分方法列表
        
        Returns:
            切分方法名称列表
        """
        return list(self.SPLITTER_TYPES.keys())
    
    def preview_split(
        self,
        text: str,
        method: str = "recursive",
        num_chunks: int = 3,
        **kwargs
    ) -> List[Dict]:
        """
        预览文本切分效果
        
        Args:
            text: 要切分的文本
            method: 切分方法
            num_chunks: 预览的块数
            **kwargs: 切分参数
            
        Returns:
            预览块信息列表
        """
        doc = Document(page_content=text, metadata={"preview": True})
        chunks = self.split_documents([doc], method=method, **kwargs)
        
        preview_chunks = []
        for i, chunk in enumerate(chunks[:num_chunks]):
            preview_chunks.append({
                "chunk_index": i,
                "content": chunk.page_content[:200] + "..." if len(chunk.page_content) > 200 else chunk.page_content,
                "length": len(chunk.page_content),
                "metadata": chunk.metadata
            })
        
        return preview_chunks
