from pymilvus import MilvusClient, DataType
from dotenv import load_dotenv
from utils.embedding_factory import EmbeddingFactory
from utils.embedding_config import EmbeddingProvider, EmbeddingConfig
from services.file_import_service import FileImportService
from services.text_splitter_service import TextSplitterService
from langchain_core.documents import Document
from typing import List, Dict, Optional, Literal
import logging
import asyncio
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

class KnowledgeBaseService:
    """
    金融术语知识库构建服务
    整合文件导入、文本切分、embedding生成和向量数据库存储
    """
    
    def __init__(
        self,
        provider="huggingface",
        model="BAAI/bge-m3",
        model_path=None,
        db_path="db/finance_terms_kb.db",
        collection_name="finance_terms_kb"
    ):
        """
        初始化知识库服务
        
        Args:
            provider: 嵌入模型提供商
            model: 使用的模型名称
            model_path: 本地模型路径
            db_path: Milvus数据库路径
            collection_name: 集合名称
        """
        provider_mapping = {
            'openai': EmbeddingProvider.OPENAI,
            'bedrock': EmbeddingProvider.BEDROCK,
            'huggingface': EmbeddingProvider.HUGGINGFACE
        }
        
        embedding_provider = provider_mapping.get(provider.lower())
        if embedding_provider is None:
            raise ValueError(f"Unsupported provider: {provider}")
            
        config = EmbeddingConfig(
            provider=embedding_provider,
            model_name=model,
            model_path=model_path
        )
        self.embedding_func = EmbeddingFactory.create_embedding_function(config)
        
        self.db_path = db_path
        self.collection_name = collection_name
        
        self.client = MilvusClient(db_path)
        self.file_import_service = FileImportService()
        self.text_splitter_service = TextSplitterService()
        
        self._init_collection()
    
    def _init_collection(self):
        """
        初始化或加载集合
        """
        if self.client.has_collection(self.collection_name):
            self.client.load_collection(self.collection_name)
            logger.info(f"Loaded existing collection: {self.collection_name}")
        else:
            logger.info(f"Creating new collection: {self.collection_name}")
            self._create_collection()
    
    def _create_collection(self):
        """
        创建新的集合
        """
        try:
            test_embedding = self.embedding_func.embed_query("test")
            embedding_dim = len(test_embedding)
            
            schema = MilvusClient.create_schema(
                auto_id=True,
                enable_dynamic_field=True
            )
            schema.add_field(field_name="id", datatype=DataType.INT64, is_primary=True, auto_id=True)
            schema.add_field(field_name="content", datatype=DataType.VARCHAR, max_length=65535)
            schema.add_field(field_name="embedding", datatype=DataType.FLOAT_VECTOR, dim=embedding_dim)
            
            index_params = self.client.prepare_index_params()
            index_params.add_index(
                field_name="embedding",
                index_type="HNSW",
                metric_type="COSINE",
                params={"M": 16, "efConstruction": 256}
            )
            
            self.client.create_collection(
                collection_name=self.collection_name,
                schema=schema,
                index_params=index_params
            )
            
            self.client.load_collection(self.collection_name)
            logger.info(f"Successfully created collection: {self.collection_name}")
            
        except Exception as e:
            logger.error(f"Error creating collection: {e}")
            raise
    
    async def build_from_file(
        self,
        file_path: str,
        split_method: str = "recursive",
        split_params: Optional[Dict] = None,
        progress_callback=None
    ) -> Dict:
        """
        从文件构建知识库
        
        Args:
            file_path: 文件路径
            split_method: 文本切分方法
            split_params: 切分参数
            progress_callback: 进度回调函数
            
        Returns:
            构建结果信息
        """
        result = {
            "status": "success",
            "file_path": file_path,
            "total_chunks": 0,
            "failed_chunks": 0,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "error": None
        }
        
        try:
            if progress_callback:
                await progress_callback({"step": "import", "message": f"正在导入文件: {file_path}", "progress": 10})
            
            documents = self.file_import_service.import_file(file_path)
            
            if progress_callback:
                await progress_callback({"step": "split", "message": f"正在切分文本，文档数: {len(documents)}", "progress": 30})
            
            if split_params is None:
                split_params = {
                    "chunk_size": 1000,
                    "chunk_overlap": 200,
                    "language": "chinese"
                }
            
            chunks = self.text_splitter_service.split_documents(
                documents,
                method=split_method,
                **split_params
            )
            
            if progress_callback:
                await progress_callback({"step": "embedding", "message": f"正在生成embedding，块数: {len(chunks)}", "progress": 50})
            
            embeddings = []
            valid_chunks = []
            
            total_chunks = len(chunks)
            update_interval = max(1, total_chunks // 20)
            
            for i, chunk in enumerate(chunks):
                try:
                    embedding = self.embedding_func.embed_query(chunk.page_content)
                    embeddings.append(embedding)
                    valid_chunks.append(chunk)
                    
                    if progress_callback and (i % update_interval == 0 or i == total_chunks - 1):
                        progress = 50 + (i / total_chunks) * 40
                        await progress_callback({
                            "step": "embedding",
                            "message": f"正在生成embedding: {i+1}/{total_chunks} ({(i+1)/total_chunks*100:.1f}%)",
                            "progress": progress
                        })
                        
                except Exception as e:
                    logger.warning(f"Failed to embed chunk {i}: {e}")
                    result["failed_chunks"] += 1
                    continue
            
            if progress_callback:
                await progress_callback({"step": "insert", "message": f"正在插入向量数据库，有效块数: {len(valid_chunks)}", "progress": 90})
            
            if embeddings:
                data = []
                for chunk, embedding in zip(valid_chunks, embeddings):
                    data.append({
                        "content": chunk.page_content,
                        "embedding": embedding,
                        **chunk.metadata
                    })
                
                self.client.insert(
                    collection_name=self.collection_name,
                    data=data
                )
            
            result["total_chunks"] = len(valid_chunks)
            result["end_time"] = datetime.now().isoformat()
            
            if progress_callback:
                await progress_callback({"step": "complete", "message": "知识库构建完成！", "progress": 100})
            
            logger.info(f"知识库构建完成: 文件={file_path}, 总块数={result['total_chunks']}, 失败数={result['failed_chunks']}")
            
        except Exception as e:
            logger.error(f"构建知识库失败: {str(e)}")
            result["status"] = "error"
            result["error"] = str(e)
            result["end_time"] = datetime.now().isoformat()
            
            if progress_callback:
                await progress_callback({"step": "error", "message": f"构建失败: {str(e)}", "progress": 0})
        
        return result
    
    async def build_from_directory(
        self,
        directory_path: str,
        glob_pattern: str = "**/*",
        split_method: str = "recursive",
        split_params: Optional[Dict] = None,
        progress_callback=None
    ) -> Dict:
        """
        从目录批量构建知识库
        
        Args:
            directory_path: 目录路径
            glob_pattern: 文件匹配模式
            split_method: 文本切分方法
            split_params: 切分参数
            progress_callback: 进度回调函数
            
        Returns:
            构建结果信息
        """
        result = {
            "status": "success",
            "directory_path": directory_path,
            "total_files": 0,
            "total_chunks": 0,
            "failed_chunks": 0,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "error": None
        }
        
        try:
            if progress_callback:
                await progress_callback({"step": "import", "message": f"正在导入目录: {directory_path}", "progress": 5})
            
            documents = self.file_import_service.import_directory(directory_path, glob_pattern)
            result["total_files"] = len(set(doc.metadata.get('source', '') for doc in documents))
            
            if progress_callback:
                await progress_callback({"step": "split", "message": f"正在切分文本，文档数: {len(documents)}", "progress": 15})
            
            if split_params is None:
                split_params = {
                    "chunk_size": 1000,
                    "chunk_overlap": 200,
                    "language": "chinese"
                }
            
            chunks = self.text_splitter_service.split_documents(
                documents,
                method=split_method,
                **split_params
            )
            
            if progress_callback:
                await progress_callback({"step": "embedding", "message": f"正在生成embedding，块数: {len(chunks)}", "progress": 25})
            
            embeddings = []
            valid_chunks = []
            
            for i, chunk in enumerate(chunks):
                try:
                    embedding = self.embedding_func.embed_query(chunk.page_content)
                    embeddings.append(embedding)
                    valid_chunks.append(chunk)
                    
                    if progress_callback and i % 50 == 0:
                        progress = 25 + (i / len(chunks)) * 65
                        await progress_callback({
                            "step": "embedding",
                            "message": f"正在生成embedding: {i}/{len(chunks)}",
                            "progress": progress
                        })
                        
                except Exception as e:
                    logger.warning(f"Failed to embed chunk {i}: {e}")
                    result["failed_chunks"] += 1
                    continue
            
            if progress_callback:
                await progress_callback({"step": "insert", "message": f"正在插入向量数据库，有效块数: {len(valid_chunks)}", "progress": 95})
            
            if embeddings:
                data = []
                for chunk, embedding in zip(valid_chunks, embeddings):
                    data.append({
                        "content": chunk.page_content,
                        "embedding": embedding,
                        **chunk.metadata
                    })
                
                self.client.insert(
                    collection_name=self.collection_name,
                    data=data
                )
            
            result["total_chunks"] = len(valid_chunks)
            result["end_time"] = datetime.now().isoformat()
            
            if progress_callback:
                await progress_callback({"step": "complete", "message": "知识库构建完成！", "progress": 100})
            
            logger.info(f"知识库构建完成: 目录={directory_path}, 文件数={result['total_files']}, 总块数={result['total_chunks']}, 失败数={result['failed_chunks']}")
            
        except Exception as e:
            logger.error(f"构建知识库失败: {str(e)}")
            result["status"] = "error"
            result["error"] = str(e)
            result["end_time"] = datetime.now().isoformat()
            
            if progress_callback:
                await progress_callback({"step": "error", "message": f"构建失败: {str(e)}", "progress": 0})
        
        return result
    
    async def build_from_text(
        self,
        text: str,
        metadata: Optional[Dict] = None,
        split_method: str = "recursive",
        split_params: Optional[Dict] = None,
        progress_callback=None
    ) -> Dict:
        """
        从文本内容构建知识库
        
        Args:
            text: 文本内容
            metadata: 元数据
            split_method: 文本切分方法
            split_params: 切分参数
            progress_callback: 进度回调函数
            
        Returns:
            构建结果信息
        """
        result = {
            "status": "success",
            "total_chunks": 0,
            "failed_chunks": 0,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "error": None
        }
        
        try:
            if progress_callback:
                await progress_callback({"step": "create_document", "message": "正在创建文档", "progress": 10})
            
            if metadata is None:
                metadata = {}
            
            document = Document(page_content=text, metadata=metadata)
            
            if progress_callback:
                await progress_callback({"step": "split", "message": "正在切分文本", "progress": 30})
            
            if split_params is None:
                split_params = {
                    "chunk_size": 1000,
                    "chunk_overlap": 200,
                    "language": "chinese"
                }
            
            chunks = self.text_splitter_service.split_documents(
                [document],
                method=split_method,
                **split_params
            )
            
            if progress_callback:
                await progress_callback({"step": "embedding", "message": f"正在生成embedding，块数: {len(chunks)}", "progress": 50})
            
            embeddings = []
            valid_chunks = []
            
            for i, chunk in enumerate(chunks):
                try:
                    embedding = self.embedding_func.embed_query(chunk.page_content)
                    embeddings.append(embedding)
                    valid_chunks.append(chunk)
                    
                    if progress_callback:
                        progress = 50 + (i / len(chunks)) * 40
                        await progress_callback({
                            "step": "embedding",
                            "message": f"正在生成embedding: {i}/{len(chunks)}",
                            "progress": progress
                        })
                        
                except Exception as e:
                    logger.warning(f"Failed to embed chunk {i}: {e}")
                    result["failed_chunks"] += 1
                    continue
            
            if progress_callback:
                await progress_callback({"step": "insert", "message": f"正在插入向量数据库，有效块数: {len(valid_chunks)}", "progress": 90})
            
            if embeddings:
                data = []
                for chunk, embedding in zip(valid_chunks, embeddings):
                    data.append({
                        "content": chunk.page_content,
                        "embedding": embedding,
                        **chunk.metadata
                    })
                
                self.client.insert(
                    collection_name=self.collection_name,
                    data=data
                )
            
            result["total_chunks"] = len(valid_chunks)
            result["end_time"] = datetime.now().isoformat()
            
            if progress_callback:
                await progress_callback({"step": "complete", "message": "知识库构建完成！", "progress": 100})
            
            logger.info(f"知识库构建完成: 总块数={result['total_chunks']}, 失败数={result['failed_chunks']}")
            
        except Exception as e:
            logger.error(f"构建知识库失败: {str(e)}")
            result["status"] = "error"
            result["error"] = str(e)
            result["end_time"] = datetime.now().isoformat()
            
            if progress_callback:
                await progress_callback({"step": "error", "message": f"构建失败: {str(e)}", "progress": 0})
        
        return result
    
    def search(self, query: str, limit: int = 5, filter_expr: Optional[str] = None) -> List[Dict]:
        """
        搜索知识库
        
        Args:
            query: 查询文本
            limit: 返回结果数量
            filter_expr: 过滤表达式
            
        Returns:
            搜索结果列表
        """
        try:
            query_embedding = self.embedding_func.embed_query(query)
            
            search_params = {
                "collection_name": self.collection_name,
                "data": [query_embedding],
                "limit": limit,
                "output_fields": ["content"]
            }
            
            if filter_expr:
                search_params["filter"] = filter_expr
            
            search_result = self.client.search(**search_params)

            results = []
            if search_result and len(search_result) > 0:
                for hit in search_result[0]:
                    results.append({
                        "content": hit['entity'].get('content', ''),
                        "distance": float(hit['distance']),
                        "metadata": {k: v for k, v in hit['entity'].items() if k != 'content' and k != 'embedding'}
                    })

            return results
            
        except Exception as e:
            logger.error(f"搜索失败: {str(e)}")
            raise
    
    def get_collection_stats(self) -> Dict:
        """
        获取集合统计信息
        
        Returns:
            统计信息字典
        """
        try:
            stats = self.client.get_collection_stats(collection_name=self.collection_name)
            return {
                "total_count": stats.get("row_count", 0),
                "collection_name": self.collection_name,
                "db_path": self.db_path
            }
        except Exception as e:
            logger.error(f"获取集合统计信息失败: {str(e)}")
            return {
                "total_count": 0,
                "collection_name": self.collection_name,
                "db_path": self.db_path,
                "error": str(e)
            }
    
    def clear_collection(self):
        """
        清空集合
        """
        if self.client.has_collection(self.collection_name):
            self.client.drop_collection(self.collection_name)
            logger.info(f"已清空集合: {self.collection_name}")
            self._create_collection()
    
    def rebuild_collection(self):
        """
        重建集合（删除并重新创建）
        """
        self.clear_collection()
        logger.info(f"已重建集合: {self.collection_name}")
    
    def preview_chunks(self, limit: int = 10) -> List[Dict]:
        """
        预览知识库中的文本块
        
        Args:
            limit: 预览数量
            
        Returns:
            文本块列表
        """
        try:
            result = self.client.query(
                collection_name=self.collection_name,
                output_fields=["content"],
                limit=limit
            )
            
            chunks = []
            for item in result:
                chunks.append({
                    "content": item.get('content', ''),
                    "metadata": {k: v for k, v in item.items() if k != 'content' and k != 'embedding'}
                })
            
            return chunks
            
        except Exception as e:
            logger.error(f"预览块失败: {str(e)}")
            return []
    
    def __del__(self):
        """清理资源，释放集合"""
        if hasattr(self, 'client') and hasattr(self, 'collection_name'):
            try:
                self.client.release_collection(self.collection_name)
            except:
                pass
