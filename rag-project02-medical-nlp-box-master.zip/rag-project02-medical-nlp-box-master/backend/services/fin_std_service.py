from pymilvus import MilvusClient, DataType
from dotenv import load_dotenv
from utils.embedding_factory import EmbeddingFactory
from utils.embedding_config import EmbeddingProvider, EmbeddingConfig
import pandas as pd
import os
from typing import List, Dict, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

class FinStdService:
    """
    金融术语标准化服务
    使用向量数据库进行金融术语的标准化和相似度搜索
    """
    
    def __init__(self, 
                 provider="huggingface",
                 model="BAAI/bge-m3",
                 model_path=None,
                 db_path="db/finance_terms.db",
                 collection_name="finance_terms",
                 csv_path="../万条金融标准术语.csv"):
        """
        初始化金融术语标准化服务
        
        Args:
            provider: 嵌入模型提供商 (openai/bedrock/huggingface)
            model: 使用的模型名称
            model_path: 本地模型路径
            db_path: Milvus 数据库路径
            collection_name: 集合名称
            csv_path: 金融术语CSV文件路径
        """
        provider_mapping = {
            'openai': EmbeddingProvider.OPENAI,
            'bedrock': EmbeddingProvider.BEDROCK,
            'huggingface': EmbeddingProvider.HUGGINGFACE
        }
        
        embedding_provider = provider_mapping.get(provider.lower())
        if embedding_provider is None:
            raise ValueError(f"Unsupported provider: {provider}")
            
        config = EmbeddingConfig(
            provider=embedding_provider,
            model_name=model,
            model_path=model_path
        )
        self.embedding_func = EmbeddingFactory.create_embedding_function(config)
        
        self.db_path = db_path
        self.collection_name = collection_name
        self.csv_path = csv_path
        
        self.client = MilvusClient(db_path)
        self._init_collection()
        
    def _init_collection(self):
        """
        初始化或加载集合
        """
        if self.client.has_collection(self.collection_name):
            self.client.load_collection(self.collection_name)
            logger.info(f"Loaded existing collection: {self.collection_name}")
        else:
            logger.info(f"Creating new collection: {self.collection_name}")
            self._create_collection_from_csv()
    
    def _create_collection_from_csv(self):
        """
        从CSV文件创建集合并导入数据
        """
        try:
            df = pd.read_csv(self.csv_path, header=None, names=['term', 'category'])
            logger.info(f"Loaded {len(df)} finance terms from CSV")
            
            embeddings = []
            terms = []
            categories = []
            
            for idx, row in df.iterrows():
                term = str(row['term']).strip()
                category = str(row['category']).strip()
                
                if term and not pd.isna(row['term']):
                    try:
                        embedding = self.embedding_func.embed_query(term)
                        embeddings.append(embedding)
                        terms.append(term)
                        categories.append(category)
                    except Exception as e:
                        logger.warning(f"Failed to embed term '{term}': {e}")
                        continue
            
            if not embeddings:
                logger.error("No valid embeddings generated")
                return
            
            embedding_dim = len(embeddings[0])
            
            schema = MilvusClient.create_schema(
                auto_id=True,
                enable_dynamic_field=True
            )
            schema.add_field(field_name="term", datatype=DataType.VARCHAR, max_length=512)
            schema.add_field(field_name="category", datatype=DataType.VARCHAR, max_length=64)
            schema.add_field(field_name="embedding", datatype=DataType.FLOAT_VECTOR, dim=embedding_dim)
            
            self.client.create_collection(
                collection_name=self.collection_name,
                schema=schema
            )
            
            data = [{
                "term": term,
                "category": category,
                "embedding": embedding
            } for term, category, embedding in zip(terms, categories, embeddings)]
            
            self.client.insert(
                collection_name=self.collection_name,
                data=data
            )
            
            self.client.load_collection(self.collection_name)
            logger.info(f"Successfully created collection with {len(data)} terms")
            
        except Exception as e:
            logger.error(f"Error creating collection from CSV: {e}")
            raise
    
    def search_similar_terms(self, query: str, limit: int = 5, category_filter: Optional[str] = None) -> List[Dict]:
        """
        搜索与查询文本相似的金融术语
        
        Args:
            query: 查询文本
            limit: 返回结果的最大数量
            category_filter: 类别过滤条件
            
        Returns:
            包含相似术语信息的列表，每个术语包含：
            - term: 术语
            - category: 类别
            - distance: 相似度距离
        """
        query_embedding = self.embedding_func.embed_query(query)
        
        search_params = {
            "collection_name": self.collection_name,
            "data": [query_embedding],
            "limit": limit,
            "output_fields": ["term", "category"]
        }
        
        if category_filter:
            search_params["filter"] = f"category == '{category_filter}'"
        
        search_result = self.client.search(**search_params)

        results = []
        if search_result and len(search_result) > 0:
            for hit in search_result[0]:
                results.append({
                    "term": hit['entity'].get('term'),
                    "category": hit['entity'].get('category'),
                    "distance": float(hit['distance'])
                })

        return results
    
    def standardize_term(self, query: str, limit: int = 3) -> Dict:
        """
        标准化金融术语
        
        Args:
            query: 待标准化的术语
            limit: 返回候选术语数量
            
        Returns:
            标准化结果，包含：
            - original_term: 原始术语
            - standardized_term: 标准术语
            - category: 类别
            - confidence: 置信度
            - alternatives: 备选术语列表
        """
        similar_terms = self.search_similar_terms(query, limit=limit)
        
        if not similar_terms:
            return {
                "original_term": query,
                "standardized_term": query,
                "category": "UNKNOWN",
                "confidence": 0.0,
                "alternatives": []
            }
        
        best_match = similar_terms[0]
        confidence = max(0.0, 1.0 - best_match['distance'])
        
        return {
            "original_term": query,
            "standardized_term": best_match['term'],
            "category": best_match['category'],
            "confidence": round(confidence, 4),
            "alternatives": similar_terms[1:]
        }
    
    def get_categories(self) -> List[str]:
        """
        获取所有术语类别
        
        Returns:
            类别列表
        """
        if not self.client.has_collection(self.collection_name):
            return []
        
        try:
            result = self.client.query(
                collection_name=self.collection_name,
                output_fields=["category"]
            )
            categories = set()
            for item in result:
                if 'category' in item:
                    categories.add(item['category'])
            return sorted(list(categories))
        except Exception as e:
            logger.error(f"Error getting categories: {e}")
            return []
    
    def rebuild_collection(self):
        """
        重建集合（删除并重新创建）
        """
        if self.client.has_collection(self.collection_name):
            self.client.drop_collection(self.collection_name)
            logger.info(f"Dropped collection: {self.collection_name}")
        
        self._create_collection_from_csv()
    
    def __del__(self):
        """清理资源，释放集合"""
        if hasattr(self, 'client') and hasattr(self, 'collection_name'):
            try:
                self.client.release_collection(self.collection_name)
            except:
                pass
