#!/usr/bin/env python3.11
import requests
import json
import sys

BASE_URL = "http://127.0.0.1:8000"

def test_financial_standardization():
    print("\n" + "="*50)
    print("测试1: 金融术语标准化功能")
    print("="*50)
    
    try:
        payload = {
            "text": "股票",
            "options": {},
            "embeddingOptions": {
                "provider": "huggingface",
                "model": "BAAI/bge-m3",
                "modelPath": "/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
                "dbName": "finance_terms",
                "collectionName": "finance_terms"
            }
        }
        
        response = requests.post(f"{BASE_URL}/api/fin-std", json=payload)
        print(f"状态码: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ 金融术语标准化测试成功")
            print(f"结果: {json.dumps(result, indent=2, ensure_ascii=False)}")
            return True
        else:
            print(f"❌ 金融术语标准化测试失败: {response.text}")
            return False
    except Exception as e:
        print(f"❌ 金融术语标准化测试出错: {str(e)}")
        return False

def test_file_upload():
    print("\n" + "="*50)
    print("测试2: 文件上传功能")
    print("="*50)
    
    try:
        files = {'file': ('test.txt', b'This is a test file content.', 'text/plain')}
        response = requests.post(f"{BASE_URL}/api/upload", files=files)
        print(f"状态码: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ 文件上传测试成功")
            print(f"文件路径: {result.get('filePath')}")
            return result.get('filePath')
        else:
            print(f"❌ 文件上传测试失败: {response.text}")
            return None
    except Exception as e:
        print(f"❌ 文件上传测试出错: {str(e)}")
        return None

def test_knowledge_base_build(file_path=None):
    print("\n" + "="*50)
    print("测试3: 知识库构建功能")
    print("="*50)
    
    try:
        payload = {
            "sourceType": "text",
            "text": "这是一个关于金融知识的测试文本。股票是公司所有权的一部分，代表股东对公司的所有权。",
            "metadata": {},
            "splitMethod": "recursive",
            "splitParams": {
                "chunk_size": 100,
                "chunk_overlap": 20
            },
            "embeddingOptions": {
                "provider": "huggingface",
                "model": "BAAI/bge-m3",
                "modelPath": "/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
                "dbName": "test_kb",
                "collectionName": "test_kb"
            }
        }
        
        response = requests.post(f"{BASE_URL}/api/kb/build", json=payload)
        print(f"状态码: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ 知识库构建测试成功")
            print(f"结果: {json.dumps(result, indent=2, ensure_ascii=False)}")
            return True
        else:
            print(f"❌ 知识库构建测试失败: {response.text}")
            return False
    except Exception as e:
        print(f"❌ 知识库构建测试出错: {str(e)}")
        return False

def test_knowledge_base_search():
    print("\n" + "="*50)
    print("测试4: 知识库搜索功能")
    print("="*50)
    
    try:
        payload = {
            "query": "股票",
            "limit": 3,
            "embeddingOptions": {
                "provider": "huggingface",
                "model": "BAAI/bge-m3",
                "modelPath": "/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
                "dbName": "test_kb",
                "collectionName": "test_kb"
            }
        }
        
        response = requests.post(f"{BASE_URL}/api/kb/search", json=payload)
        print(f"状态码: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ 知识库搜索测试成功")
            print(f"结果: {json.dumps(result, indent=2, ensure_ascii=False)}")
            return True
        else:
            print(f"❌ 知识库搜索测试失败: {response.text}")
            return False
    except Exception as e:
        print(f"❌ 知识库搜索测试出错: {str(e)}")
        return False

def test_split_methods():
    print("\n" + "="*50)
    print("测试5: 文本切分方法获取")
    print("="*50)
    
    try:
        response = requests.get(f"{BASE_URL}/api/split/methods")
        print(f"状态码: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ 文本切分方法获取成功")
            print(f"支持的方法: {list(result.get('methods', {}).keys())}")
            return True
        else:
            print(f"❌ 文本切分方法获取失败: {response.text}")
            return False
    except Exception as e:
        print(f"❌ 文本切分方法获取出错: {str(e)}")
        return False

def main():
    print("\n" + "="*50)
    print("开始测试核心功能")
    print("="*50)
    
    results = []
    
    results.append(("金融术语标准化", test_financial_standardization()))
    file_path = test_file_upload()
    results.append(("文件上传", file_path is not None))
    results.append(("知识库构建", test_knowledge_base_build()))
    results.append(("知识库搜索", test_knowledge_base_search()))
    results.append(("文本切分方法", test_split_methods()))
    
    print("\n" + "="*50)
    print("测试结果汇总")
    print("="*50)
    
    for name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{name}: {status}")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    print(f"\n总计: {passed}/{total} 测试通过")
    
    if passed == total:
        print("\n🎉 所有核心功能测试通过！")
        return 0
    else:
        print(f"\n⚠️  有 {total - passed} 个测试失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())
