from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, ConfigDict
from services.fin_std_service import FinStdService
from services.knowledge_base_service import KnowledgeBaseService
from services.file_import_service import FileImportService
from services.text_splitter_service import TextSplitterService
from typing import Dict, List, Optional, Literal
import logging
import asyncio
import os
import shutil

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],    
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class BaseInputModel(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    llmOptions: Dict[str, str] = Field(
        default_factory=lambda: {
            "provider": "deepseek",
            "model": "deepseek-chat"
        },
        description="大语言模型配置选项"
    )

class EmbeddingOptions(BaseModel):
    provider: str = Field(
        default="huggingface",
        description="向量数据库提供商"
    )
    model: str = Field(
        default="BAAI/bge-m3",
        description="嵌入模型名称"
    )
    modelPath: Optional[str] = Field(
        default="/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
        description="本地模型路径"
    )
    dbName: str = Field(
        default="finance_terms",
        description="向量数据库名称"
    )
    collectionName: str = Field(
        default="finance_terms",
        description="集合名称"
    )

class TextInput(BaseInputModel):
    text: str = Field(..., description="输入文本")
    options: Dict[str, bool] = Field(
        default_factory=dict,
        description="处理选项"
    )
    termTypes: Dict[str, bool] = Field(
        default_factory=dict,
        description="术语类型"
    )
    embeddingOptions: EmbeddingOptions = Field(
        default_factory=EmbeddingOptions,
        description="向量数据库配置选项"
    )

class KnowledgeBaseInput(BaseInputModel):
    sourceType: Literal["file", "directory", "text"] = Field(
        ...,
        description="数据源类型"
    )
    filePath: Optional[str] = Field(
        None,
        description="文件路径"
    )
    directoryPath: Optional[str] = Field(
        None,
        description="目录路径"
    )
    globPattern: str = Field(
        default="**/*",
        description="文件匹配模式"
    )
    text: Optional[str] = Field(
        None,
        description="文本内容"
    )
    metadata: Optional[Dict] = Field(
        None,
        description="元数据"
    )
    splitMethod: Literal["character", "recursive", "token", "paragraph", "sentence", "fixed_length"] = Field(
        default="recursive",
        description="文本切分方法"
    )
    splitParams: Optional[Dict] = Field(
        None,
        description="文本切分参数"
    )
    embeddingOptions: EmbeddingOptions = Field(
        default_factory=EmbeddingOptions,
        description="向量数据库配置选项"
    )

class SearchInput(BaseInputModel):
    query: str = Field(..., description="查询文本")
    limit: int = Field(
        default=5,
        description="返回结果数量"
    )
    filterExpr: Optional[str] = Field(
        None,
        description="过滤表达式"
    )
    embeddingOptions: EmbeddingOptions = Field(
        default_factory=EmbeddingOptions,
        description="向量数据库配置选项"
    )

class SplitPreviewInput(BaseInputModel):
    text: str = Field(..., description="要切分的文本")
    method: Literal["character", "recursive", "token", "paragraph", "sentence", "fixed_length"] = Field(
        default="recursive",
        description="切分方法"
    )
    splitParams: Optional[Dict] = Field(
        None,
        description="切分参数"
    )
    numChunks: int = Field(
        default=3,
        description="预览的块数"
    )

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        file_location = f"{UPLOAD_DIR}/{file.filename}"
        
        with open(file_location, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        logger.info(f"File uploaded: {file.filename} to {file_location}")
        
        return {
            "message": "File uploaded successfully",
            "filename": file.filename,
            "filePath": os.path.abspath(file_location)
        }
    except Exception as e:
        logger.error(f"Error uploading file: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/fin-std")
async def financial_standardization(input: TextInput):
    try:
        logger.info(f"Received financial standardization request: text={input.text}, embeddingOptions={input.embeddingOptions}")

        fin_std_service_instance = FinStdService(
            provider=input.embeddingOptions.provider,
            model=input.embeddingOptions.model,
            model_path=input.embeddingOptions.modelPath,
            db_path=f"db/{input.embeddingOptions.dbName}.db",
            collection_name=input.embeddingOptions.collectionName
        )

        std_result = fin_std_service_instance.standardize_term(input.text, limit=5)

        return {
            "message": "Financial term standardization completed",
            "original_text": input.text,
            "standardized_result": std_result
        }

    except Exception as e:
        logger.error(f"Error in financial standardization processing: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/kb/build")
async def build_knowledge_base(input: KnowledgeBaseInput):
    try:
        logger.info(f"Received knowledge base build request: sourceType={input.sourceType}")

        kb_service = KnowledgeBaseService(
            provider=input.embeddingOptions.provider,
            model=input.embeddingOptions.model,
            model_path=input.embeddingOptions.modelPath,
            db_path=f"db/{input.embeddingOptions.dbName}.db",
            collection_name=input.embeddingOptions.collectionName
        )

        progress_updates = []
        async def progress_callback(update):
            progress_updates.append(update)

        if input.sourceType == "file":
            if not input.filePath:
                raise HTTPException(status_code=400, detail="filePath is required for file source")
            result = await kb_service.build_from_file(
                input.filePath,
                input.splitMethod,
                input.splitParams,
                progress_callback=progress_callback
            )
        elif input.sourceType == "directory":
            if not input.directoryPath:
                raise HTTPException(status_code=400, detail="directoryPath is required for directory source")
            result = await kb_service.build_from_directory(
                input.directoryPath,
                input.globPattern,
                input.splitMethod,
                input.splitParams,
                progress_callback=progress_callback
            )
        elif input.sourceType == "text":
            if not input.text:
                raise HTTPException(status_code=400, detail="text is required for text source")
            result = await kb_service.build_from_text(
                input.text,
                input.metadata,
                input.splitMethod,
                input.splitParams,
                progress_callback=progress_callback
            )
        else:
            raise HTTPException(status_code=400, detail="Invalid sourceType")

        return {
            "message": "Knowledge base build completed",
            "result": result,
            "progress_updates": progress_updates
        }

    except Exception as e:
        logger.error(f"Error in knowledge base build: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/kb/search")
async def search_knowledge_base(input: SearchInput):
    try:
        logger.info(f"Received knowledge base search request: query={input.query}")

        kb_service = KnowledgeBaseService(
            provider=input.embeddingOptions.provider,
            model=input.embeddingOptions.model,
            model_path=input.embeddingOptions.modelPath,
            db_path=f"db/{input.embeddingOptions.dbName}.db",
            collection_name=input.embeddingOptions.collectionName
        )

        results = kb_service.search(input.query, input.limit, input.filterExpr)

        return {
            "message": "Search completed",
            "query": input.query,
            "results": results
        }

    except Exception as e:
        logger.error(f"Error in knowledge base search: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/kb/stats")
async def get_knowledge_base_stats(dbName: str = "finance_terms_kb", collectionName: str = "finance_terms_kb"):
    try:
        kb_service = KnowledgeBaseService(
            provider="huggingface",
            model="BAAI/bge-m3",
            model_path="/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
            db_path=f"db/{dbName}.db",
            collection_name=collectionName
        )

        stats = kb_service.get_collection_stats()

        return {
            "message": "Stats retrieved",
            "stats": stats
        }

    except Exception as e:
        logger.error(f"Error getting knowledge base stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/kb/preview")
async def preview_knowledge_base(limit: int = 10, dbName: str = "finance_terms_kb", collectionName: str = "finance_terms_kb"):
    try:
        kb_service = KnowledgeBaseService(
            provider="huggingface",
            model="BAAI/bge-m3",
            model_path="/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
            db_path=f"db/{dbName}.db",
            collection_name=collectionName
        )

        chunks = kb_service.preview_chunks(limit)

        return {
            "message": "Preview retrieved",
            "chunks": chunks
        }

    except Exception as e:
        logger.error(f"Error previewing knowledge base: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/kb/clear")
async def clear_knowledge_base(dbName: str = "finance_terms_kb", collectionName: str = "finance_terms_kb"):
    try:
        kb_service = KnowledgeBaseService(
            provider="huggingface",
            model="BAAI/bge-m3",
            model_path="/Users/xujieyi/.cache/modelscope/hub/models/BAAI/bge-m3",
            db_path=f"db/{dbName}.db",
            collection_name=collectionName
        )

        kb_service.clear_collection()

        return {
            "message": "Knowledge base cleared",
            "dbName": dbName,
            "collectionName": collectionName
        }

    except Exception as e:
        logger.error(f"Error clearing knowledge base: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/split/preview")
async def preview_text_split(input: SplitPreviewInput):
    try:
        logger.info(f"Received split preview request: method={input.method}")

        splitter_service = TextSplitterService()

        split_params = input.splitParams or {}
        preview_chunks = splitter_service.preview_split(
            input.text,
            input.method,
            input.numChunks,
            **split_params
        )

        return {
            "message": "Split preview completed",
            "method": input.method,
            "chunks": preview_chunks
        }

    except Exception as e:
        logger.error(f"Error in split preview: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/split/methods")
async def get_split_methods():
    try:
        splitter_service = TextSplitterService()
        methods = {}

        for method in splitter_service.get_supported_methods():
            methods[method] = splitter_service.get_splitter_info(method)

        return {
            "message": "Split methods retrieved",
            "methods": methods
        }

    except Exception as e:
        logger.error(f"Error getting split methods: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/import/formats")
async def get_supported_formats():
    try:
        import_service = FileImportService()
        formats = import_service.get_supported_formats()

        return {
            "message": "Supported formats retrieved",
            "formats": formats
        }

    except Exception as e:
        logger.error(f"Error getting supported formats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
